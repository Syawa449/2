package com.epam.izh.rd.online;

public class Main {

    public static void main(String[] args) {

    }

}
